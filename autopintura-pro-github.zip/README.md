# AutoPintura Pro

Sitio web local para ayudar a trabajadores de taller automotriz con soluciones rapidas sobre pintura, pulido, enderezado, preparacion y entrega de vehiculos.

## Funciones

- Diagnostico de problemas comunes: piel de naranja, chorreo, ojo de pescado, diferencia de tono, hologramas, rayas de pulido, masilla marcada y panel ondulado.
- Guias paso a paso para preparacion, base color, barniz, pulido y enderezado.
- Calculadora de mezcla de producto por relacion.
- Estimador basico de material por pieza y numero de manos.
- Checklist de entrega con guardado local en el navegador.

## Como abrirlo

Abre el archivo `index.html` en cualquier navegador moderno.

Tambien puedes correr un servidor local:

```bash
python -m http.server 4173
```

Luego abre:

```text
http://127.0.0.1:4173/
```

## Como subirlo a GitHub

1. Crea un repositorio nuevo en GitHub.
2. Instala Git si no lo tienes.
3. Entra a la carpeta del proyecto.
4. Ejecuta estos comandos:

```bash
git init
git add .
git commit -m "Crear sitio AutoPintura Pro"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
git push -u origin main
```

Cambia `TU-USUARIO` y `TU-REPOSITORIO` por los datos reales de tu repositorio.

## Publicarlo con GitHub Pages

1. En GitHub entra a tu repositorio.
2. Ve a `Settings`.
3. Entra a `Pages`.
4. En `Build and deployment`, selecciona `Deploy from a branch`.
5. Elige la rama `main` y la carpeta `/root`.
6. Guarda los cambios.

Despues GitHub te dara un enlace publico parecido a:

```text
https://TU-USUARIO.github.io/TU-REPOSITORIO/
```

## Archivos principales

- `index.html`: estructura del sitio.
- `styles.css`: diseno visual.
- `app.js`: datos, busqueda, calculadoras y checklist.

## Nota tecnica

La informacion tecnica incluida es una base practica general. Para productos reales, relaciones de mezcla, tiempos de secado, presion de pistola y compatibilidades, siempre se debe confirmar la ficha tecnica del fabricante.
